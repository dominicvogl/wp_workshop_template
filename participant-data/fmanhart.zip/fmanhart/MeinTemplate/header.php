<!DOCTYPE html>
<html lang="de">

<head>

   <title>Wordpress Workshop - 08 CSS Praxis</title>
   
   

 <!-- Lade das Stylesheet -->
 
   <link rel="stylesheet/less" type="text/less" href="<?php bloginfo('template_url')?>/less/all.less" media="all" />

</head>

<body>
<header class="module-header">

   <div class="inner-content">

      <div class="row">

         <div class="logo">
            <img src="<?php bloginfo('template_url')?>/assets/logo.svg" width="300" alt="Wordpress Logo"/>
         </div>
         <!-- /.column -->

         <div class="navigation">
            
			<!-- hier wird ein Nav-Menü gebaut -->
			
			<?php 
			wp_nav_menu(
				array(
					'container' => '',
					'menu_class' => 'header-menu',
					'link_before' => '<span class="button">',
					'link_after' => '</span>'
				)
			);
			?>
			
			
         </div>
         <!-- /.column -->

      </div>
      <!-- /.row -->

   </div>
   <!-- /.inner-content -->
   
<?php wp_head(); ?>  

<!-- allgemeiner metatag f. javascriptect. laden -->


</header>
<!-- /.module-header -->

<body>