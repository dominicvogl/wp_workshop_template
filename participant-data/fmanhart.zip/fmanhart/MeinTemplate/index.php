

<!--importiere hier den header aus der header.php -->

<?php get_header(); ?>

<div class="row">
   <div class="column">
      <h2>Willkommen auf meinem Blog</h2>
   </div>
</div>
   
   <div class="row">
   <?php
	if(have_posts()) {
		while(have_posts()) {
			// Das was für den jeweiligen Beitrag getan werden soll.
			
			the_post ();
			
			?>
	
	<div class="column">

    <div class="inner-content">
			
		<h3><?php the_title(); //Die Überschrift wird dynamisch angezeigt ?></h3>	
			
		<div class="post-date"><?php echo get_the_date('D.m.Y'); //hier greift es das Datenbank-Datum ab ?> </div>
		
			
			<?php the_post_thumbnail('medium');//holt sich den Thumbnail ?>
			
			
			<?php the_content(); //Holt sich den Inhalt ?>
			
			<a href="#" class="button">Zum Artikel</a>
			
		</div>
		</div>
<?php
		}
	}	
	?>		
	
	
   

         

        

</div>
<!-- /.row -->

<?php get_footer(); ?>


<!-- Lade den Less Compiler -->
<script src="<?php bloginfo('template_url')?>/js/lib/less.min.js"></script>

</body>

</html>
