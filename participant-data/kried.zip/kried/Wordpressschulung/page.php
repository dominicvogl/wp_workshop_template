<!-- Importiere den Header (header.php) -->
<?php get_header();?>






<div class="row">

   <?php
   // Prüfen ob Beiträge vorhanden sind
   if(have_posts()){
	   // Wenn Beiträge vorhanden sind tue ich etwas
	   while(have_posts()){
		   // Das was für den jeweiligen Beitrag getan werden soll.
		   the_post();
		   ?>
		   
		   
	<div class="column">

      <div class="inner-content">
		 <?php 	echo the_post_thumbnail('medium'); ?>
         <h3><?php the_title();?></h3>

         <div class="post-date"><?php echo get_the_date('d m Y');?></div>
		<hr />
		 <div style="clear:both"></div>
         <?php 	echo the_content(); ?>
		 <div style="clear:both"></div>

      </div>
      <!-- /.inner-content -->

   </div>
			
		<?php
	   }	   
   }
?>
</div>
<?php get_footer(); ?>
