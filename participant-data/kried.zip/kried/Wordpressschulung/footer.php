  
   
   
   
   

<footer class="module module-footer">

   <div class="row">

      <div class="column small-12 medium-6">
         <p>&copy; 2015 Design & Umsetzung: <a href="#" target="_blank">Karin Ried</a></p>
      </div>

      <!-- /.column -->

   </div>
   <!-- row -->

</footer>

</body>

	<!-- Lade den Less Compiler -->
	<script src="<?php bloginfo('template_url')?>/js/less.min.js"></script>
	<?php wp_footer(); ?>

</html>