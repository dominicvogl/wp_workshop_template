<footer class="module module-footer">

   <div class="row">

      <div class="column small-12 medium-6">
         <p>&copy; 2015 Design & Umsetzung: <a href="#" target="_blank">Dein Name</a></p>
      </div>

<div class="navigation">
            
			<?php	
			wp_nav_menu(
				array(
					'container' => '',
					'menu_class' => 'header-menu',
					'link_before' => '<span class="button">',
					'link_after' => '</span>'
				
				)
			
			);
			?>
			

			
			
			
         </div>
      <!-- /.column -->

   </div>
   <!-- row -->
   
   </footer>
   
<script src="<?php bloginfo('template_url') ?>/js/less.min.js"></script>

<?php wp_footer(); ?>

</body>

</html>