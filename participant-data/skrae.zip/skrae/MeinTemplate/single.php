<?php get_header(); ?>

<div class="row">
 
		 <?php 
		 //Loop Beiträge werden angezeigt
		 if (have_posts()) {
			while(have_posts()){
			the_post();
			?>
			
   <div class="column">

      <div class="inner-content">

         <?php the_post_thumbnail ('medium'); ?>
		  
		 <h3><?php the_title();?></h3>

         <div class="post-date"><?php echo get_the_date('d.m.Y'); ?></div>
		 
		
		 
		
		
		 
		 <?php the_content(); ?>

		<span class="button"><a href="<?php echo home_url(); ?>">Zurück</span>
      </div>
      <!-- /.inner-content -->

   </div>

	<?php
	}	 
	 }
	?>
 

 </div>

</div>
<!-- /.row -->


<?php get_footer(); ?>
