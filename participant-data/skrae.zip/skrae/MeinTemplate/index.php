<?php get_header(); ?>
<div id="wrapper">
<div class="row">
 
 <div class="column">
     <div class="column title">
	 <div class="inner-content">
	 
	<?php the_title('<h2>','</h2>') ?>
	 </div>
	 </div>
	 
   </div>



 

		 <?php 
		 //Loop Beiträge werden angezeigt
		 if (have_posts()) {
			while(have_posts()){
			the_post();
			?>
			
   <div class="column">

      <div class="inner-content">

         <?php the_post_thumbnail ('medium'); ?>
		  
		 <h3><?php the_title();?></h3>

         <div class="post-date"><?php echo get_the_date('d.m.Y'); ?></div>
		 
		
		 
		
		 
		 <?php the_content(); ?>
		 
         <a href="<?php echo get_permalink($post->ID); ?>" class="button">Zum Artikel</a>

      </div>
      <!-- /.inner-content -->

   </div>

	<?php
	}	 
	 }
	 wp_reset_postdata();
	?>
 

 </div>
 <div class="row">
 
 <div class="column medium-1">
	<div class="inner-content">
		
		<?php
		
		$post = get_post(68);
		
		if(!empty($post)) {
			setup_postdata($post);
			
			echo get_the_content($post->ID);
		}
		
		wp_reset_postdata();
		
		?>
		
	</div>
</div>
	
	
<div class="column medium-1">
	<div class="inner-content">
		
		<?php
		
		$post = get_post(70);
		
		if(!empty($post)) {
			setup_postdata($post);
			
			echo get_the_content($post->ID);
		}
		
		wp_reset_postdata();
		
		?>
		
	</div>
</div>

<!-- Box füllen -->

<div class="column medium-1">
	<div class="inner-content">
		
		<?php
		
		$post = get_post(72);
		
		if(!empty($post)) {
			setup_postdata($post);
			

			
			echo get_the_content($post->ID);
		}
		
		wp_reset_postdata();
		
		?>
		
	</div>
</div>
 

   
   </div>
</div>
<!-- /.row -->


<?php get_footer(); ?>
