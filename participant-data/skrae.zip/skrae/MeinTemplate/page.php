<?php get_header(); ?>

<div class="row">
 
 <div class="column">
     <div class="column title">
	 <div class="inner-content">
	 
	<?php the_title('<h2>','</h2>') ?>
	 </div>
	 </div>
	 
   </div>



 

		 <?php 
		 //Loop Beiträge werden angezeigt
		 if (have_posts()) {
			while(have_posts()){
			the_post();
			?>
			
   <div class="column">

      <div class="inner-content">

         <?php the_post_thumbnail ('medium'); ?>
		  
		 <h3><?php the_title();?></h3>


		 
		
		 
		
		 
		 <?php the_content(); ?>
		 


      </div>
      <!-- /.inner-content -->

   </div>

	<?php
	}	 
	 }
	?>
 

 </div>
 
</div>
<!-- /.row -->


<?php get_footer(); ?>
