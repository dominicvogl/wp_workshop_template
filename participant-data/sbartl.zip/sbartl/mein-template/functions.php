<?php

//Erlaubt Post Thumbnail im Template

add_theme_support('post-thumbnails');

//PHP muss man nur schlie�en, wenn es mehr Funktionen sind, also wenn noch was anderes als php drin steht, zb html.

//Registriere navigation Men�s

function register_my_menu()
{
	register_nav_menu('primary',__('header-menu', 'theme-slug'));
}

add_action('after_setup_theme', 'register_my_menu');