<!DOCTYPE html>
<html lang="de">

<head>

   <title>Wordpress Workshop - 08 CSS Praxis</title>

   
   <!-- IMPORTIERE DEINE HAUPT CSS DATEI -->
   <link href="css/normalize.css" rel="stylesheet" type="text/css" media="all"/>
   <link href="<?php bloginfo('template_url')?>/less/master_02.less" rel="stylesheet" type="text/less" media="all"/>
   
<?php wp_head(); ?>
</head>

<body>


<header class="module-header">

   <div class="inner-content">

      <div class="row">

	  <div class="logo">
            <img src="<?php bloginfo('template_url')?>/assets/logo.svg" width="150" alt="Wordpress Logo"/>
         </div>
         <!-- /.column -->

         <div class="navigation-4">
           
			 <?php wp_nav_menu(array
		 (
		 'container' => '',
		 'menu_class' => 'header-menu',
		 'link_before' => '<span class="button">',
		 'link_after' => '</span>')
		 );
		 ?>
		 
         </div>
		
		 
         <!-- /.column -->
		 
		

      </div>
      <!-- /.row -->

   </div>
   <!-- /.inner-content -->

</header>
