
<?php get_header(); ?>

<div class="row">
   <div class="column medium-2">
      
   </div>
   		    <div class="column medium-8">
   <?php
   //Prüfen ob Beiträge vorhanden sind
   if(have_posts()) {
	   //Wenn Beiträge vorhanden sind tue etwas
	   while(have_posts()){
		   //Das was für den jeweiligen Beitrag getan werden soll.
		   the_post();
		   ?>
		   
			   <div class="post">

				  <div class="inner-content">

					<div class="postheader">
						<h3><?php the_title();?> /// <span class="post-date"><?php echo get_the_date('D.m.Y');?></span></h3>

						 
						 <?php the_post_thumbnail();?> 
					</div>

						 <?php the_content();?>
						 
						 <a href="<?php echo home_url(); ?>">
						 <span class="button">zurück</span>
						 </a>

						

				  </div>
      <!-- /.inner-content -->
			   </div>
			
		   		  				  		   		   
		   <?php
	   }
	   
   }
   ?>
   </div>

  

   <div class="column medium-4">

      <div class="inner-content">

        
         <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Transfer idem ad modestiam vel temperantiam, quae
            est moderatio cupiditatum rationi oboediens. Hic nihil fuit, quod quaereremus. Nonne igitur tibi videntur,
            inquit, mala?</p>

         <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Transfer idem ad modestiam vel temperantiam, quae
            est moderatio cupiditatum rationi oboediens. Hic nihil fuit, quod quaereremus. Nonne igitur tibi videntur,
            inquit, mala?</p>
			
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Transfer idem ad modestiam vel temperantiam, quae
		   est moderatio cupiditatum rationi oboediens. Hic nihil fuit, quod quaereremus. Nonne igitur tibi videntur,
		   inquit, mala?</p>
		   
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Transfer idem ad modestiam vel temperantiam, quae
            est moderatio cupiditatum rationi oboediens. Hic nihil fuit, quod quaereremus. Nonne igitur tibi videntur,
            inquit, mala?</p>
			
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Transfer idem ad modestiam vel temperantiam, quae
            est moderatio cupiditatum rationi oboediens. Hic nihil fuit, quod quaereremus. Nonne igitur tibi videntur,
            inquit, mala?</p>

         <a href="#" class="button">weiterlesen</a>

      </div>
      <!-- /.inner-content -->

   </div>
   <!-- /.column -->

</div>
<!-- /.row -->

<?php get_footer(); ?>



