<footer class="module module-footer">

   <div class="row">

      <div class="column small-12 medium-6">
         <p>&copy; 2015 Design & Umsetzung: <a href="#" target="_blank">Dein Name</a></p>
      </div>

      <div class="navigation-8">

         <ul>
            <li><a href="#"><span>Button1</span></a></li>
            <li><a href="#"><span>Button2</span></a></li>
			<li><a href="#"><span>Button3</span></a></li>
			<li><a href="#"><span>Button4</span></a></li>
			<li><a href="#"><span>Button5</span></a></li>
         </ul>

      </div>
      <!-- /.column -->

   </div>
   <!-- row -->
   

</footer>

<script src="<?php bloginfo('template_url')?>/js/less.min.js"></script>

<?php wp_footer(); ?>
</body>


</html>