<footer class="module module-footer">
	<?php wp_footer(); ?>

   <div class="row">

      <div class="column small-12 medium-6">
         <p>&copy; 2015 Design & Umsetzung</p>
      </div>

      <div class="column small-12 medium-6">


      </div>
      <!-- /.column -->

   </div>
   <!-- row -->

</footer>
<script src="<?php bloginfo('template_url')?>/js/less.min.js"></script>
</body>

</html>