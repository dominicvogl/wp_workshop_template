<!-- Importiere den Header (header.php) -->
<?php get_header(); ?>
	
	
	<div class="slider">
		<img src="<?php bloginfo('template_url')?>/images/konzert_02.jpg">
	</div>
	
	<div class="row">

	<?php
	//Prüfen ob Beiträge vorhanden sind
	if(have_posts()) {
		//Wenn Beiträge vorhanden, tue etwas
		while(have_posts()) {
			//Das was für den jeweiligen Beitrag getan werden soll.
			the_post();
			
			?>

			<div class="column">
					
					<div class="no-background">
					
						<h3><?php the_title();?></h3>
							<?php the_content();?>	
					
				</div>
			</div><!-- /.column -->
				
				
		<?php 
		}
	}
	?>
	
</div><!-- /.row -->

<div class="clear"></div>

<?php get_footer(); ?>