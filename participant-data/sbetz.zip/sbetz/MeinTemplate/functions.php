<?php

//Erlaube Post Thumbnails im Template
add_theme_support('post-thumbnails');

//Registriere Navigation Menüs

function register_my_menu()
{
	register_nav_menu('primary',__('header-menu', 'theme-slug'));
}

	add_action('after_setup_theme', 'register_my_menu');

	
	// Removes ul class from wp_nav_menu
function remove_ul ( $menu ){
    return preg_replace( array( '#^<ul[^>]*>#', '#</ul>$#' ), '', $menu );
}
add_filter( 'wp_nav_menu', 'remove_ul' );


function remove_more_link($link) { 
	$offset = strpos($link, '#more-');
	if ($offset) { $end = strpos($link, '"',$offset); }
	if ($end) { $link = substr_replace($link, '', $offset, $end-$offset); }
	return $link;
}
add_filter('the_content_more_link', 'remove_more_link');


?>
