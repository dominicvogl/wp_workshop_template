<!-- Importiere den Header (header.php) -->
<?php get_header(); ?>
	
	<div class="neu">
		<h2>Willkommen <br/> auf meinem Blog</h2>
	</div>

	<div class="slider">
		<img src="<?php bloginfo('template_url')?>/images/konzert_02.jpg">
	</div>
	
	<div class="row">
	<?php
	//Prüfen ob Beiträge vorhanden sind
	if(have_posts()) {
		//Wenn Beiträge vorhanden, tue etwas
		while(have_posts()) {
			//Das was für den jeweiligen Beitrag getan werden soll.
			the_post();			
			?>

			<div class="column no-background">
						
						<h3><?php the_title();?></h3>
							<div class="post-date">
								<?php echo get_the_date ('D.m Y');?>
							</div>
							
							<?php the_content();?>
							<a href="<?php echo home_url($post->ID); ?>" <span class="button">Zürück zur Startseite</span></a>
					
				</div>
			</div><!-- /.column -->
				
				
		<?php 
		}
	}
	?>
	
</div><!-- /.row -->

<div class="clear"></div>

<?php get_footer(); ?>