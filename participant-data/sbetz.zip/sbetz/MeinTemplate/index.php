<!-- Importiere den Header (header.php) -->
<?php get_header(); ?>
	
	<div class="neu">
		<h2>Willkommen <br/> auf meinem Blog</h2>
	</div>

	<div class="slider">
		<img src="<?php bloginfo('template_url')?>/images/konzert_02.jpg">
	</div>
	
	<div class="row">

	<div class="leiste_links">
		<hr class="linie">
		
		<?php 
		
		$pages = get_post(2);
		
		if(!empty($pages)) {
			setup_postdata($pages);
			echo get_the_content($pages->ID);
		}
		?>
		
		<hr class="linie">
	</div> 
	
	<div class="leiste_rechts">
	<?php
	//Prüfen ob Beiträge vorhanden sind
	if(have_posts()) {
		//Wenn Beiträge vorhanden, tue etwas
		while(have_posts()) {
			//Das was für den jeweiligen Beitrag getan werden soll.
			the_post();
			
			$thumbnail = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full');
			
			?>

			<div class="column">
					
					<?php
				if(has_post_thumbnail()) { ?>
					<div class="background-image" style="background-image:url(<?php echo $thumbnail[0] ?>);">
					<?php
				}
				else {
					?>
					<div class="no-background">
					<?php
				}
			
			?>
						<h3><?php the_title();?></h3>
							<div class="post-date">
								<?php echo get_the_date ('D.m Y');?>
							</div>
							<?php the_content();?>
							<a href="<?php echo get_permalink($post->ID); ?>"><span class="button">Zum Artikel</span></a>
					
				</div>
			</div><!-- /.column -->
				
				
		<?php 
		}
	}
	?>
	
	</div>
</div><!-- /.row -->

<div class="clear"></div>

<?php get_footer(); ?>