<!DOCTYPE html>
<html lang="de">

<head>

   <title>Mein Template</title>
   
   <!-- IMPORTIERE DEINE HAUPT CSS DATEI -->
   <link href="css/normalize.css" rel="stylesheet" type="text/css" media="all"/>
   <!--<link href="css/master_02.css" rel="stylesheet" type="text/css" media="all"/>-->
   <link href="<?php bloginfo('template_url')?>/less/master_02.less" rel="stylesheet/less" type="text/css" media="all"/>
	
	<?php wp_head(); ?>
   
</head>

<body>

<header class="module-header">

	<div class="inner-content">

      <div class="row">

         <div class="logo">
            <img src="<?php bloginfo('template_url')?>/assets/logo.svg" width="300" alt="Wordpress Logo"/>
         </div><!-- /.logo -->

         <div class="navigation">
           			
			<ul id="menu-eisbrecher" class="header-menu nav_header">
				<li>
					<a href="<?php echo home_url($post->ID); ?>" <span class="button">Home</span></a>
				</li>
				<?php
				wp_nav_menu(
				array(
					'container' => '',
					
					'menu_class' => 'header-menu nav_header',
				
					)
					);
					?>
			</ul>
         </div>
		 <!-- /.navigation-->

      </div>
      <!-- /.row -->
	</div>
	<!-- /.inner-content -->

</header>
<!-- /.module-header -->