


<footer class="module module-footer">

   <div class="row">

      

      <div class="column small-12 medium-6">

         <ul>
            <li><a href="#"><span class="button_footer">Blog</span></a></li>
            <li><a href="#"><span class="button_footer">&Uuml;ber mich</span></a></li>
         </ul>

      </div>
      <!-- /.column -->
	  
	  <div class="column small-12 medium-6">
         <p>&copy; 2015 Design & Umsetzung: <a href="#" target="_blank">CaRina</a></p>
      </div>

   </div>
   <!-- row -->

</footer>

<!-- Lade den Less Compiler -->
<script src="<?php bloginfo('template_url')?>/js/less.min.js"></script>

<?php wp_footer(); ?>

</body>

</html>
