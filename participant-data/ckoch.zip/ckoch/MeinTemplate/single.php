
<!-- Importiere den Header (header.php)-->
<?php get_header(); ?>

<div class="row">
	
	<div id="titelbild">
            <img src="<?php bloginfo('template_url')?>/images/header_01.jpg" width="100%" alt="Titelbild"/>
    </div>
	
   <hr>
   
</div>
<div class="row">

	<?php
	
	//Prüfen ob Beiträge vorhanden sind
	if(have_posts()) {
		
		//Wenn Beiträge vorhanden sind, tue etwas
		while(have_posts()){
			//Das für den jeweiligen Beitrag getan werden soll.
			the_post();
			?>
			
	<div class="column medium-4">

      <div class="inner-content">
	  
		<div class="text-inner-content">
			<div class="thumbnail"><?php the_post_thumbnail ('medium');?></div>
			<!-- <img src="assets/konzert_01.jpg" width="960" height="307" alt="Konzertfoto"/> -->
        </div>
		
		<h3><?php the_title();?></h3>

         <div class="post-date"><?php echo get_the_date('d m Y'); ?></div>
         
		 
		<?php the_content(); ?>
         
		<a href="<?php echo home_url(); ?>">
			<span class="button">Zurück zur Startseite</span>
		</a>
         

      </div>
      <!-- /.inner-content -->

   </div>
   <!-- /.column -->
   
   <?php
		}
	}
?>
</div>
			
	<?php get_footer(); ?>		
			
