<?php get_header(); ?> <!-- HEADER-IMPORT -->

    <div class="row">
        
    <div class="column">
        <h2 style="margin-top:0.4em"><?php bloginfo('name'); ?></h2>
    </div>

    <?php
    

///////////////////////////////////////////////////////////////////////////////////////////////////


    if(have_posts()) { // Wenn Beiträge vorhanden sind
        while(have_posts()) { // Mach wat.
                  
            the_post(); //Dat wat.
            ?>
    
        <div class="column">

            <div class="inner-content">

                <?php the_content();?>

            </div>

        </div>
        
    <?php
            };
    }
    ?> 
        
        
        </div>
<?php get_footer(); ?>