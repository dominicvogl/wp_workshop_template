<?php get_header(); ?> <!-- HEADER-IMPORT -->

    <div class="row">
        
    <div class="column">
        <h2 style="margin-top:0.4em"><?php bloginfo('name'); ?></h2>
    </div>

    <?php
    
    $inc = 0;

///////////////////////////////////////////////////////////////////////////////////////////////////

    // Funktion, die die Nummer des Posts auf der Seite Modulo 2 nimmt. Bei Rest 0 wird der Blogpost rechtsbündig gesetzt, bei Ergebnis 1 linksbündig.

    if(have_posts()) { // Wenn Beiträge vorhanden sind
        while(have_posts()) { // Mach wat.
            if($inc % 2 == 0) {
                  
            the_post(); //Dat wat.
            ?>
    
        <div class="column">

            <div class="inner-content">

                <h3 style="text-align:right"><?php the_title();?></h3>

                <div class="post-date"><?php echo get_the_date('D d.m.Y');?></div>
          
                <hr class="right">
          
                <?php
                
                // String-Array-Variable mit der URL des Blog-Thumbnails
                $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail_size' ); 
                ?>
                
                <div id="blogpic" style="background-image:url( <?php echo $thumb['0']; ?> )"></div>

                <div class="textblock"><?php the_content();?></div>

                <a href="<?php echo get_permalink($post->ID); ?>" class="button" style="margin-top:1em">Zum Artikel</a>

            </div>

        </div>
        
    <?php
            $inc = ++$inc;
            } else {
            the_post();
    ?> 
        
        <div class="column">

            <div class="inner-content">

                <h3><?php the_title();?></h3>

                <div style="margin-top:0.5em;margin-bottom:0.5em"><?php echo get_the_date('D d.m.Y');?></div>
          
                <hr>
          
                <?php
                
                // String-Array-Variable mit der URL des Blog-Thumbnails
                $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail_size' ); 
                ?>
                
                <div id="blogpic" style="background-image:url( <?php echo $thumb['0']; ?> )"></div>
                
                <div class="textblock"><?php the_content();?></div>

                <a href="<?php echo get_permalink($post->ID); ?>" class="button" style="float:right;margin-top:1em">Zum Artikel</a>
 
                <br><br><br>

            </div>

        </div>
        
        <?php
            $inc = ++$inc;
            }
        }
    }
        ?>
        
        </div>
<?php get_footer(); ?>