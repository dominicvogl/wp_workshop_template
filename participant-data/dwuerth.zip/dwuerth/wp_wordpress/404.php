<?php get_header(); ?> <!-- HEADER-IMPORT -->

    <div class="row">
        
    <div class="column">
        <h2 style="margin-top:0.4em"><?php bloginfo('name'); ?></h2>
    </div>
    
        <div class="column">

            <div class="inner-content">

                <h2 style="text-align:center;margin-bottom:0.5em">Oh noes!</h2>
                
                <h3 style="text-align:center">You 404'd!</h3>
                <br>

                <div style="text-align:center">No content here for you.<br>Sorry for that.<br>The kitty will take you back to content =^.^=</div>
                
                <a href="<?php echo home_url(); ?>"><img src="<?php bloginfo('template_url')?>/assets/kitty.svg" style="margin-left:35%;margin-top:3em;" width="30%"></a>

        </div>
        
        
        </div>
<?php get_footer(); ?>