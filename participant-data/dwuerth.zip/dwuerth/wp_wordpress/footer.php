<footer id="dere" class="module module-footer" style="background-image: url(<?php bloginfo('template_url');?>/assets/hbg.jpg);overflow:hidden;">

   <div class="row">

        <ul id="bottom">
            <li><a href="#"><span class="button">Blog</span></a></li>
            <li><a href="#"><span class="button">&Uuml;ber mich</span></a></li>
            <li style="float:right;"><a href="http://facebook.com"><img src="<?php bloginfo('template_url')?>/assets/fb.svg" style="height:2.5em"></a></li>
        </ul>
       
        <p class="small">&copy; 2015 Design & Umsetzung: <a href="http://opraging.lima-city.de/dominik/start.html">Dominik W&uuml;rth</a>, im Rahmen des Wordpress-Kurses der Städtischen Berufsschule II Regensburg in den Pfingstferien 2015.</p>
       
        <hr id="blueline">
       
        <p class="small">Know-How & Anleitung: Dominic Vogl - <a href="http://bergwerk.ag" alt="Bergwerk.AG">Bergwerk.ag</a></p>

   </div>

</footer>
    
    <script src="<?php bloginfo('template_url')?>/js/less.min.js"></script>
    
    <?php wp_footer(); ?>

</body>

</html>