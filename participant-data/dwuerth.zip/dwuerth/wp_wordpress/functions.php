<?php

// Erlaube Post Thumbnails im Template

add_theme_support('post-thumbnails');

// Registriere Navigation Menüs

function register_my_menu()
{
    register_nav_menu('primary', __('header-menu', 'theme-slug'));
}

add_action('after_setup_theme', 'register_my_menu');