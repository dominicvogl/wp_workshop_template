<!DOCTYPE html>
<html lang="de">

<head>

   <title>Wordpress Workshop - Template</title>

    <meta charset="utf-8">
    <link href="css/normalize.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="<?php bloginfo('template_url')?>/less/main.less" rel="stylesheet/less" type="text/css" media="all"/>

    <? wp_head(); ?>
    
</head>

<body>

<header class="module-header">

   <div class="inner-content" id="dere" style="background-image: url(<?php bloginfo('template_url');?>/assets/hbg.jpg);overflow:hidden;">
       
      <div class="row">

         <div class="logo">
            <img src="<?php bloginfo('template_url')?>/assets/leaf.svg" width="80" alt="Wordpress Logo"/>
         </div>
          
            <?php
                wp_nav_menu(
                    array(
                        'container' => '',
                        'menu_class' => 'header_menu',
                        'link_before' => '<span class="button">',
                        'link_after' => '</span>'
                    )
                );
            ?>
          
         </div>

      </div>

   </div>

</header>