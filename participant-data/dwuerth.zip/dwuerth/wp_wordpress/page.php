<?php get_header(); ?> <!-- HEADER-IMPORT -->

    <div class="row">
        
    <div class="column">
        <h2 style="margin-top:0.4em"><?php bloginfo('name'); ?></h2>
    </div>

    <?php
    

///////////////////////////////////////////////////////////////////////////////////////////////////


    if(have_posts()) { // Wenn Beiträge vorhanden sind
        while(have_posts()) { // Mach wat.
                  
            the_post(); //Dat wat.
            ?>
    
        <div class="column">

            <div class="inner-content">

                <h3 style="text-align:right"><?php the_title();?></h3>
          
                <?php
                
                // String-Array-Variable mit der URL des Blog-Thumbnails
                $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail_size' ); 
                ?>
                
                <div id="blogpic" style="background-image:url( <?php echo $thumb['0']; ?> )"></div>

                <?php the_content();?>

            </div>

        </div>
        
    <?php
            };
    }
    ?> 
        
        
        </div>
<?php get_footer(); ?>