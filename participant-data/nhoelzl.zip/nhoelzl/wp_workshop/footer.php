<footer class="module module-footer">

   <div class="row">

      <div class="column small-12 medium-6">
         <p>&copy; 2015 Design & Umsetzung: <a href="#" target="_blank">Dein Name</a></p>
      </div>

      <div class="column small-12 medium-6">

         <ul>
            <li><a href="#"><span class="button">Blog</span></a></li>
            <li><a href="#"><span class="button">&Uuml;ber mich</span></a></li>
         </ul>

      </div>
      <!-- /.column -->

   </div>
   <!-- row -->

</footer>

<!-- Lade den Less Compiler -->
<script src="<?php bloginfo('template_url'); ?>/js/lib/less.min.js"></script>

<?php wp_footer ?>

</body>

</html>