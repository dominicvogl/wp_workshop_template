<!DOCTYPE html>
<html lang="de">

<head>

   <title>Wordpress Workshop - 08 CSS Praxis</title>
  
   <!-- IMPORTIERE DEINE HAUPT CSS/LESS DATEI -->
   <link rel="stylesheet/less" type="text/less" href="<?php bloginfo('template_url'); ?>/less/all.less" media="all" />

   <!-- meta-tags, javascripts, etc. laden !-->
   <?php wp_head(); ?>
</head>

<body>
<header class="module-header">

   <div class="inner-content">

      <div class="row">

         <div class="logo">
            <img src="<?php bloginfo('template_url'); ?>/assets/logo.svg" width="300" alt="Wordpress Logo"/>
         </div>
         <!-- /.column -->

         <div class="navigation">
            <?php
			wp_nav_menu(
				array(
					'container' => '',
					'menu_class' => 'header-menu',
					'link_before' => '<span class="button">',
					'link_after' => '</span>'
				)
			);
			?>
         </div>
         <!-- /.column -->

      </div>
      <!-- /.row -->

   </div>
   <!-- /.inner-content -->

</header>
<!-- /.module-header -->