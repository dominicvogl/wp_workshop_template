<!-- Importiere den header !-->
<?php get_header(); ?>


<div class="row">
   <div class="column">
      <h2>Willkommen auf meinem Blog</h2>
   </div>

   
   <?php 
   
   //Prüfen, ob Posts vorhanden sind
   if(have_posts())  {
   
		//wenn Beiträge vorhanden tue etwas
		while(have_posts()) {		//das was für den jeweiligen Beitrag getan werden soll. 
			the_post();				//sorgt dafür, dass die restlichen Attribute zur Verfügung stehen
	?>
			
			<div class="column">

				<div class="inner-content">			
			
					<h3><?php the_title();  //Titelattribut des Posts ?></h3>

					<div class="post-date"><?php the_time('j. F, Y');	//Datum des Posts ?></div>
					
					<?php the_post_thumbnail('medium');	//Holt sich den Thumbnail zum Post, wenn es einen gibt ?>

					<?php the_content(); //Inhalt des Posts ?>
					
					<a href="#" class="button">Zum Artikel</a>

				</div>
				<!-- /.inner-content -->

			</div>
			<!-- /.column -->
			
			
	<?php 		

		}
   }
   ?>   
   
 </div>
<!-- /.row -->


<!-- Importiere den footer !-->
<?php get_footer(); ?>
